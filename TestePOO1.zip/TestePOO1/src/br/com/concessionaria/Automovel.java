package br.com.concessionaria;


public class Automovel {
    // TODO 03: declare 03 atributos compatíveis com a classe Automovel:
    
    // TODO 04: encapsule os atributos da classe Automovel:
    
    // TODO 05: crie os construtores não-parametrizado e parametrizados 
    // da classe Automovel:
    
    // TODO 06: Crie uma função para imprimir o valor de todos os atributos
    // da classe Automovel e da sua super classe (se houver)
    // (essa função não recebe e nem retorna valores):
    
}
