package br.com.concessionaria;


public class Carro {
    // TODO 07: declare 02 atributos compatíveis com a classe Carro:
    
    // TODO 08: encapsule os atributos da classe Carro:
    
    // TODO 09: crie os construtores não-parametrizado e parametrizados 
    // da classe Carro:
    
    // TODO 10: Crie uma função para imprimir o valor de todos os atributos
    // da classe Carro e da sua super classe (se houver)
    // (essa função não recebe e nem retorna valores):
    
}
