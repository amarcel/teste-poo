package testepoo1;

    // TODO 00: informe o nome completo e matrícula da dupla:
    // Nome 1: 
    // Matrícula 1: 
    // Nome 2: 
    // Matrícula 2: 

public class TestePOO1 {
    // TODO 01: leia a descrição inicial deste projeto: trata-se de um projeto para
    // uma concessionária de veículos automotores (carros, motos, ônibus e caminhões).
    // Por enquanto, há duas classes criadas: Automovel e Carro
    // IMPORTANTE: cada TODO feito corretamente vale 0,20 décimos, 
    // exceto a TAREFA 00 e 01. TOTAL: 3,0 pontos. 
    // Após fazer o TODO, escreva "FEITO" no lugar de "TODO".
    // Projetos iguais ou muito parecidos não serão considerados
    
    // TODO 02: realize o relacionamento de herança entre as classes
    // Automovel e Carro
    public static void main(String[] args) {
        // TODO 11: Aqui, crie um objeto da classe Carro através do construtor
        // parametrizado e chame o método que imprime todos os valores dos
        // atributos:
        
        // TODO 12: Reanalise o projeto e o cenário descrito e 
        // crie uma terceira classe a sua escolha
        
        // TODO 13: Faça o relacionamento de herança entre a classe que você criou
        // e uma das duas classes que já fazem parte do projeto
        
        // TODO 14: Declare 02 atributos na classe que foi criada na TAREFA 12
        
        // TODO 15: Encapsule os atributos criados na classe da TAREFA 14
        
        // TODO 16: Crie os construtores parametrizados e não parametrizados da 
        // classe da TAREFA 12
        
    }

}
